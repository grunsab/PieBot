//! Arch-v2 NNUE parity tests: dual-perspective feature encoding must match
//! the Python trainer byte-for-byte, incremental accumulator updates must
//! match full recomputation exactly, and the SCReLU integer head must match
//! a reference implementation.

use cozy_chess::{Board, Color};
use piebot::eval::nnue::features::{dp_active_indices, HALFKP_DP_PER_PERSPECTIVE_DIM};
use piebot::eval::nnue::loader::{QuantMeta, QuantNnue, QuantNnueV2};
use piebot::eval::nnue::network::QuantNetwork;
use std::sync::Arc;

fn lcg(seed: &mut u64) -> u64 {
    *seed = seed.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
    *seed
}

fn random_v2_model(hidden: usize, seed: u64) -> QuantNnue {
    let input = HALFKP_DP_PER_PERSPECTIVE_DIM;
    let mut s = seed;
    let w1: Vec<i16> = (0..input * hidden)
        .map(|_| (lcg(&mut s) % 61) as i16 - 30)
        .collect();
    let b1: Vec<i16> = (0..hidden).map(|_| (lcg(&mut s) % 41) as i16 - 20).collect();
    let w2: Vec<i8> = (0..2 * hidden)
        .map(|_| (lcg(&mut s) % 121) as i8 - 60)
        .collect();
    let v2 = QuantNnueV2 {
        per_perspective_input_dim: input,
        hidden_dim: hidden,
        qa: 255,
        qb: 64,
        scale: 400,
        w1,
        b1,
        w2,
        b2: 137,
    };
    QuantNnue {
        meta: QuantMeta {
            version: 1,
            input_dim: input,
            hidden_dim: hidden,
            output_dim: 1,
        },
        w1_scale: 1.0,
        w2_scale: 1.0,
        w1: Vec::new(),
        b1: Vec::new(),
        w2: Vec::new(),
        b2: Vec::new(),
        v2: Some(Arc::new(v2)),
    }
}

#[test]
fn dual_perspective_indices_match_python_fixture() {
    let raw = include_str!("data/halfkp_dp_fixture.json");
    let fixture: serde_json::Value = serde_json::from_str(raw).expect("valid fixture json");
    assert_eq!(
        fixture["per_perspective_dim"].as_u64().unwrap() as usize,
        HALFKP_DP_PER_PERSPECTIVE_DIM
    );
    let positions = fixture["positions"].as_array().unwrap();
    assert!(!positions.is_empty());
    for row in positions {
        let fen = row["fen"].as_str().unwrap();
        let board = Board::from_fen(fen, false).expect("valid fen");
        for (key, perspective) in [
            ("white_perspective", Color::White),
            ("black_perspective", Color::Black),
        ] {
            let mut rust: Vec<usize> = dp_active_indices(&board, perspective);
            rust.sort_unstable();
            let python: Vec<usize> = row[key]
                .as_array()
                .unwrap()
                .iter()
                .map(|v| v.as_u64().unwrap() as usize)
                .collect();
            assert_eq!(rust, python, "fen={fen} perspective={perspective:?}");
        }
        let stm_is_white = row["stm_is_white"].as_bool().unwrap();
        assert_eq!(board.side_to_move() == Color::White, stm_is_white, "fen={fen}");
    }
}

#[test]
fn incremental_updates_match_full_recompute_over_random_games() {
    let mut net = QuantNetwork::new(random_v2_model(8, 0x5eed_a11c_e5));
    let mut seed = 20260808u64;
    for game in 0..24 {
        let mut board = Board::default();
        net.refresh(&board);
        let mut undo = Vec::new();
        for ply in 0..60 {
            assert_eq!(
                net.eval_current(),
                net.eval_full(&board),
                "game={game} ply={ply} incremental accumulator diverged"
            );
            let mut moves = Vec::new();
            board.generate_moves(|batch| {
                moves.extend(batch);
                false
            });
            if moves.is_empty() {
                break;
            }
            let mv = moves[(lcg(&mut seed) as usize) % moves.len()];
            let before = board.clone();
            board.play_unchecked(mv);
            undo.push(net.apply_move(&before, mv, &board));
        }
        // Walking the change stack back down must restore state exactly.
        for change in undo.into_iter().rev() {
            net.revert(change);
        }
        net.refresh(&board);
    }
}

#[test]
fn unwinding_a_deep_line_restores_every_ancestor_exactly() {
    // The accumulator is ply-indexed: applying a move writes a new slot and
    // reverting is an index decrement, so each move's weight rows are read
    // once on the way down instead of a second time on the way back up (when
    // the subtree has already evicted them). This pins the invariant that
    // makes that sound -- every ancestor must be bit-identical after unwind,
    // including across the king moves that force a full refresh, and past the
    // stack's initial capacity so the growth path is covered.
    let mut net = QuantNetwork::new(random_v2_model(32, 0x57ac_c0de_2026));
    let mut seed = 0xda7a_5eedu64;
    for game in 0..12 {
        let mut board = Board::default();
        net.refresh(&board);
        let mut undo = Vec::new();
        let mut ancestors = Vec::new();
        for ply in 0..90 {
            ancestors.push((board.clone(), net.eval_current()));
            let mut moves = Vec::new();
            board.generate_moves(|batch| {
                moves.extend(batch);
                false
            });
            if moves.is_empty() {
                break;
            }
            let mv = moves[(lcg(&mut seed) as usize) % moves.len()];
            let before = board.clone();
            board.play_unchecked(mv);
            undo.push(net.apply_move(&before, mv, &board));
            assert_eq!(
                net.eval_current(),
                net.eval_full(&board),
                "game={game} ply={ply}: descending accumulator diverged",
            );
        }
        while let Some(change) = undo.pop() {
            net.revert(change);
            let (ancestor, want) = ancestors.pop().expect("one ancestor per applied move");
            assert_eq!(
                net.eval_current(),
                want,
                "game={game} depth={}: unwind did not restore the ancestor",
                undo.len(),
            );
            assert_eq!(
                net.eval_current(),
                net.eval_full(&ancestor),
                "game={game} depth={}: restored accumulator disagrees with full recompute",
                undo.len(),
            );
        }
    }
}

#[test]
fn null_move_flips_the_side_to_move_seen_by_the_head() {
    // Arch-v2 is side-to-move relative: the head concatenates the stm
    // perspective first and reads a different half of w2 for each color. A
    // null move changes no piece feature, so both accumulators are untouched,
    // but the network must still be told the side to move changed. Without
    // that, the null child evaluates as the exact negation of its parent and
    // the network's tempo asymmetry is discarded -- at every null-move node.
    let mut net = QuantNetwork::new(random_v2_model(8, 0xbead_c0de_0001));
    for fen in [
        "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1",
        "r1bqk2r/pppp1ppp/2n2n2/2b1p3/2B1P3/2N2N2/PPPP1PPP/R1BQK2R b KQkq - 5 5",
        "8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1",
    ] {
        let board = Board::from_fen(fen, false).expect("valid fen");
        net.refresh(&board);
        let parent = net.eval_current();
        let nb = board.null_move().expect("position is not in check");

        let change = net.apply_null_move(&nb);
        assert_eq!(
            net.eval_current(),
            net.eval_full(&nb),
            "fen={fen}: null-move child eval must match a full recompute of the null board",
        );
        net.revert(change);
        assert_eq!(
            net.eval_current(),
            parent,
            "fen={fen}: reverting the null move must restore the parent exactly",
        );
    }
}

#[test]
fn null_move_child_is_not_merely_the_negated_parent() {
    // Guards the test above against becoming vacuous: if the head were
    // stm-symmetric, flipping the side to move would be a no-op and the bug
    // this pins would be unobservable. The two w2 halves differ, so the null
    // child's evaluation is genuinely a different number.
    // Width 256 rather than the 8 used elsewhere: the head divides by
    // qa*qa*qb = 4_161_600, so a tiny model quantizes almost every position to
    // the same handful of centipawns and the two orderings collide by
    // accident. At production width the asymmetry is visible.
    let mut net = QuantNetwork::new(random_v2_model(256, 0x0f11_9e57_2026));
    let mut differed = 0usize;
    let fens = [
        "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1",
        "r1bqk2r/pppp1ppp/2n2n2/2b1p3/2B1P3/2N2N2/PPPP1PPP/R1BQK2R b KQkq - 5 5",
        "8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1",
        "r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1",
    ];
    for fen in fens {
        let board = Board::from_fen(fen, false).expect("valid fen");
        net.refresh(&board);
        let parent = net.eval_current();
        let nb = board.null_move().expect("position is not in check");
        if net.eval_full(&nb) != -parent {
            differed += 1;
        }
    }
    assert!(
        differed > 0,
        "stm-relative head evaluated every null child as its parent's negation \
         across {} positions -- the head is behaving stm-symmetrically, which \
         would make the null-move stm flip unobservable",
        fens.len(),
    );
}

#[test]
fn python_exported_gold_model_evaluates_identically() {
    // The committed PIENNQ02 file was produced by the production Python
    // quantization path (`_export_v2_checkpoint`); the expected evals come
    // from an independent Python integer reference. Exact equality here
    // proves the full cross-language contract: trainer -> file -> engine.
    let dir = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("tests/data");
    let model = QuantNnue::load_quantized(dir.join("arch_v2_gold.nnue")).expect("load gold v2");
    assert!(model.v2.is_some(), "gold file must parse as PIENNQ02");
    let mut net = QuantNetwork::new(model);
    let expected: serde_json::Value =
        serde_json::from_str(&std::fs::read_to_string(dir.join("arch_v2_gold_expected.json")).unwrap())
            .unwrap();
    let positions = expected["positions"].as_array().unwrap();
    assert!(!positions.is_empty());
    for row in positions {
        let fen = row["fen"].as_str().unwrap();
        let want = row["eval_white_pov_cp"].as_i64().unwrap() as i32;
        let board = Board::from_fen(fen, false).expect("valid fen");
        net.refresh(&board);
        assert_eq!(net.eval_current(), want, "fen={fen}");
        assert_eq!(net.eval_full(&board), want, "fen={fen} (full path)");
    }
}

#[test]
fn screlu_head_matches_reference_formula() {
    let model = random_v2_model(8, 0xfeed_beef);
    let mut net = QuantNetwork::new(model.clone());
    let board =
        Board::from_fen("r1bqk2r/pppp1ppp/2n2n2/2b1p3/2B1P3/2N2N2/PPPP1PPP/R1BQK2R b KQkq - 5 5", false)
            .unwrap();
    net.refresh(&board);

    // Reference: recompute accumulators and the SCReLU head from scratch in
    // plain i64 arithmetic, stm half first, then flip to white-POV.
    let v2 = model.v2.as_ref().unwrap();
    let h = v2.hidden_dim;
    let mut accs = Vec::new();
    for perspective in [Color::White, Color::Black] {
        let mut acc: Vec<i64> = v2.b1.iter().map(|&b| b as i64).collect();
        for idx in dp_active_indices(&board, perspective) {
            for j in 0..h {
                acc[j] += v2.w1[idx * h + j] as i64;
            }
        }
        accs.push(acc);
    }
    let stm_black_first = [&accs[1], &accs[0]];
    let qa = v2.qa as i64;
    let mut sum = 0i64;
    for (half, acc) in stm_black_first.into_iter().enumerate() {
        for j in 0..h {
            let v = acc[j].clamp(0, qa);
            sum += v * v * (v2.w2[half * h + j] as i64);
        }
    }
    let out_stm = (sum + v2.b2 as i64) * v2.scale as i64 / (qa * qa * v2.qb as i64);
    let expected_white_pov = -(out_stm as i32); // black to move

    assert_eq!(net.eval_current(), expected_white_pov);
    assert_eq!(net.eval_full(&board), expected_white_pov);
}
