use cozy_chess::{Board as CozyBoard, Color};

#[derive(Clone, Debug)]
pub struct Position {
    board: CozyBoard,
    history: Vec<CozyBoard>,
}

impl Position {
    pub fn startpos() -> Self {
        let board = CozyBoard::default();
        Self {
            history: vec![board.clone()],
            board,
        }
    }

    pub fn from_fen(fen: &str) -> Result<Self, String> {
        CozyBoard::from_fen(fen, false)
            .map(|board| Self {
                history: vec![board.clone()],
                board,
            })
            .map_err(|e| format!("FEN error: {e:?}"))
    }

    pub fn board(&self) -> &CozyBoard {
        &self.board
    }

    /// Boards from the loaded root through the current position, inclusive.
    /// Search uses this history to recognize claimable repetitions.
    pub fn history(&self) -> &[CozyBoard] {
        &self.history
    }

    pub fn make_move_uci(&mut self, mv_uci: &str) -> Result<(), String> {
        let mut found = None;
        self.board.generate_moves(|moves| {
            for m in moves {
                if format!("{m}") == mv_uci {
                    found = Some(m);
                    break;
                }
            }
            found.is_some()
        });
        if let Some(m) = found {
            self.board.play_unchecked(m);
            self.history.push(self.board.clone());
            Ok(())
        } else {
            Err(format!("Illegal move: {mv_uci}"))
        }
    }

    pub fn legal_moves_count(&self) -> usize {
        let mut ct = 0usize;
        self.board.generate_moves(|moves| {
            ct += moves.len();
            false
        });
        ct
    }

    pub fn side_to_move(&self) -> Color {
        self.board.side_to_move()
    }

    pub fn set_from_start_and_moves(moves: &[String]) -> Result<Self, String> {
        let mut pos = Self::startpos();
        for m in moves {
            pos.make_move_uci(m)?;
        }
        Ok(pos)
    }

    pub fn set_from_fen_and_moves(fen: &str, moves: &[String]) -> Result<Self, String> {
        let mut pos = Self::from_fen(fen)?;
        for m in moves {
            pos.make_move_uci(m)?;
        }
        Ok(pos)
    }
}
