import concurrent.futures,json,os,pathlib,subprocess,time
ROOT=pathlib.Path(__file__).resolve().parents[2]
OUT=pathlib.Path(__file__).resolve().parent
for name,features in [('default',[]),('all_features',['--all-features'])]:
    metadata=OUT/f'artifacts_{name}.jsonl'
    with metadata.open('w') as dest, (OUT/f'build_tests_{name}.log').open('w') as err:
        subprocess.run(['cargo','test','--offline','--locked','--all-targets','--no-run','--message-format=json','--manifest-path',str(ROOT/'PieBot/Cargo.toml'),*features],cwd=ROOT,stdout=dest,stderr=err,check=True)
    jobs=[]
    for line in metadata.read_text().splitlines():
        try:x=json.loads(line)
        except ValueError:continue
        if x.get('reason')=='compiler-artifact' and x.get('executable') and x.get('profile',{}).get('test'):
            jobs.append({'path':x['executable'],'name':x['target']['name'],'kind':x['target']['kind']})
    jobs={j['path']:j for j in jobs};results=[]
    print(f'{name}: running {len(jobs)} test/bench executables with eight independent workers',flush=True)
    def run(job):
        path=OUT/f'{name}_{pathlib.Path(job["path"]).name}.log'
        start=time.monotonic()
        with path.open('w') as output:
            try:
                p=subprocess.run([job['path'],'--test'],cwd=ROOT/'PieBot',stdout=output,stderr=subprocess.STDOUT,timeout=600)
                code=p.returncode
            except subprocess.TimeoutExpired:code=124
        return dict(job,returncode=code,elapsed_s=time.monotonic()-start,log=str(path))
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
        for future in concurrent.futures.as_completed([pool.submit(run,j) for j in jobs.values()]):
            r=future.result();results.append(r)
            (OUT/f'rust_results_{name}.json').write_text(json.dumps(results,indent=2)+'\n')
            print(f'{name}: {len(results)}/{len(jobs)} complete; {r["name"]} exit={r["returncode"]}',flush=True)
    failed=[r for r in results if r['returncode']!=0]
    if failed:
        raise SystemExit(f'{name} failures: '+', '.join(r['name'] for r in failed))
    print(f'{name}: all {len(results)} executables passed',flush=True)
