import concurrent.futures,json,os,time
from pathlib import Path
import chess,chess.engine
P=Path(__file__).resolve().parent;ROOT=P.parents[1]
games={g['id']:g for g in map(json.loads,(P/'games.ndjson').read_text().splitlines())}
cases=[('sEi3c6E4',43),('zQoaxfK6',3),('aGvveGBK',66),('U0E0YGi4',61),('RbqMJLNn',32)]
settings=[('old_2t',2,.3),('old_2t',2,1.0),('old_1t',1,.3),('new_2t',2,.3)]
def task(args):
 gid,ply,label,threads,seconds=args;binary=ROOT/('out/thread_anchor_20260929/bin/piebot-uci' if label.startswith('new') else 'out/lazy_smp_fix_20260929/uci.before')
 e=chess.engine.SimpleEngine.popen_uci(str(binary),cwd=ROOT,env=dict(os.environ,RAYON_NUM_THREADS=str(threads)),timeout=120)
 e.configure({'Threads':threads,'Hash':512,'UseNNUE':True,'NNUEQuantFile':str(ROOT/'models/lc0_chunk_00034965.nnue'),'EvalBlend':100});e.configure({'EvalBlend':75})
 b=chess.Board(); sans=games[gid]['moves'].split();color=(ply%2==1);moves=[]
 try:
  for i,san in enumerate(sans[:ply]):
   if b.turn==color:
    r=e.play(b,chess.engine.Limit(time=seconds),info=chess.engine.INFO_ALL)
    moves.append({'ply':i+1,'move':r.move.uci(),'san':b.san(r.move),'actual':san,'score_cp_stm':r.info['score'].pov(b.turn).score(mate_score=100000),'depth':r.info.get('depth'),'nodes':r.info.get('nodes')})
   b.push_san(san)
 finally:e.quit()
 row={'game':gid,'ply':ply,'variant':label,'seconds_per_move':seconds,'note':'Replayed actual game moves after each independent engine choice, preserving search state across moves.','moves':moves}
 (P/f'replay_{gid}_{label}_{seconds}.json').write_text(json.dumps(row,indent=2)+'\n');return gid,label,seconds,moves[-1]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 for f in concurrent.futures.as_completed([pool.submit(task,(gid,ply,*s)) for s in settings for gid,ply in cases]):print(f.result(),flush=True)
