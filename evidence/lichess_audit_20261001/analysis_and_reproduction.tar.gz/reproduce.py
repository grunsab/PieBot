import hashlib,json,os,time
from pathlib import Path
import chess,chess.engine
P=Path(__file__).resolve().parent;ROOT=P.parents[1]
games={g['id']:g for g in map(json.loads,(P/'games.ndjson').read_text().splitlines())}
cases=[('sEi3c6E4',43),('zQoaxfK6',3),('aGvveGBK',66),('U0E0YGi4',61),('RbqMJLNn',32)]
variants=[('old_1t',ROOT/'out/lazy_smp_fix_20260929/uci.before',1,1),('old_2t',ROOT/'out/lazy_smp_fix_20260929/uci.before',2,5),('new_2t',ROOT/'out/thread_anchor_20260929/bin/piebot-uci',2,2)]
records=[]
for label,binary,threads,reps in variants:
 engine=chess.engine.SimpleEngine.popen_uci(str(binary),cwd=ROOT,env=dict(os.environ,RAYON_NUM_THREADS=str(threads)),timeout=120)
 engine.configure({'Threads':threads,'Hash':512,'UseNNUE':True,'NNUEQuantFile':str(ROOT/'models/lc0_chunk_00034965.nnue'),'EvalBlend':100});engine.configure({'EvalBlend':75})
 try:
  for gid,ply in cases:
   board=chess.Board()
   for san in games[gid]['moves'].split()[:ply-1]:board.push_san(san)
   for rep in range(reps):
    t=time.monotonic();r=engine.play(board,chess.engine.Limit(depth=12),game=object(),info=chess.engine.INFO_ALL)
    row={'variant':label,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'game':gid,'ply':ply,'fen':board.fen(),'rep':rep,'depth_request':12,'move':r.move.uci(),'san':board.san(r.move),'score_cp_stm':r.info['score'].pov(board.turn).score(mate_score=100000),'depth':r.info.get('depth'),'nodes':r.info.get('nodes'),'elapsed_s':time.monotonic()-t}
    records.append(row);(P/'reproductions.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True)
 finally:engine.quit()
