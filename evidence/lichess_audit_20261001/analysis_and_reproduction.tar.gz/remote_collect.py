import json,os,re,subprocess,hashlib
from pathlib import Path
import yaml
base=Path('/home/ubuntu/lichess-bot'); repo=base/'engines/PieBot'
def red(s):
 s=re.sub(r'lip_[A-Za-z0-9_-]+','<REDACTED>',s)
 s=re.sub(r'(?i)(Bearer\s+)[A-Za-z0-9_.-]+',r'\1<REDACTED>',s)
 return s
def scrub(x):
 if isinstance(x,dict): return {k:('<REDACTED>' if any(w in k.lower() for w in ('token','password','secret','authorization')) else scrub(v)) for k,v in x.items()}
 if isinstance(x,list): return [scrub(v) for v in x]
 return red(x) if isinstance(x,str) else x
def cmd(args,cwd=None):
 return subprocess.run(args,cwd=cwd,capture_output=True,text=True,timeout=15).stdout
config=scrub(yaml.safe_load((base/'config.yml').read_text()))
pids=[int(p.name) for p in Path('/proc').iterdir() if p.name.isdigit()]
processes=[]
for pid in pids:
 try:
  args=Path(f'/proc/{pid}/cmdline').read_bytes().replace(b'\0',b' ').decode()
  if 'lichess-bot.py' not in args and 'target/release/uci' not in args: continue
  if 'python -c' in args or 'ssh ' in args: continue
  env=Path(f'/proc/{pid}/environ').read_bytes().split(b'\0')
  relevant=[x.decode() for x in env if x.startswith((b'RAYON_',b'OMP_',b'PIEBOT_'))]
  processes.append({'pid':pid,'args':red(args),'cwd':os.readlink(f'/proc/{pid}/cwd'),'search_environment':relevant})
 except (PermissionError,FileNotFoundError,ProcessLookupError): pass
sources={}
for name in ('PieBot/src/uci.rs','PieBot/src/search/alphabeta.rs','PieBot/src/search/timemgmt.rs'):
 p=repo/name
 if p.exists(): sources[name]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'text':p.read_text()}
logs=[]
for p in sorted((base/'lichess_bot_auto_logs').glob('lichess-bot.log*')):
 if p.name not in ('lichess-bot.log','lichess-bot.log.2026-09-29','lichess-bot.log.2026-09-30'): continue
 for line in p.open(errors='replace'):
  if '2026-09-29 22:13:40' <= line[:19] <= '2026-10-01 22:13:40':
   if any(s in line for s in ('chess.engine','lib.engine_wrapper','lib.lichess_bot','Traceback','ERROR','WARNING')):
    if 'chatLine' not in line and 'chat message' not in line.lower(): logs.append(red(line.rstrip()))
files={}
for name in ('PieBot/target/release/uci','models/lc0_chunk_00034965.nnue'):
 p=repo/name; files[name]={'size':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'mtime':p.stat().st_mtime}
result={'config':config,'processes':processes,'files':files,'sources':sources,'logs':logs,'host':cmd(['uname','-a']),'cpu':cmd(['lscpu']),'uptime':cmd(['uptime']),'free':cmd(['free','-m']),'git_head':cmd(['git','rev-parse','HEAD'],cwd=repo).strip(),'git_status':cmd(['git','status','--short'],cwd=repo),'cpu_stat':Path('/proc/stat').read_text(),'cpu_quota':Path('/sys/fs/cgroup/cpu.max').read_text() if Path('/sys/fs/cgroup/cpu.max').exists() else None}
print(json.dumps(scrub(result)))
