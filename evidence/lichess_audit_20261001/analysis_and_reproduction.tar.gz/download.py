import datetime,getpass,hashlib,json
from pathlib import Path
import requests
OUT=Path(__file__).resolve().parent
until=datetime.datetime(2026,10,1,22,13,40,tzinfo=datetime.timezone.utc)
since=until-datetime.timedelta(hours=48)
params={'since':int(since.timestamp()*1000),'until':int(until.timestamp()*1000),'moves':'true','clocks':'true','evals':'true','opening':'true','pgnInJson':'true','sort':'dateAsc'}
secret=getpass.getpass('Lichess token (not saved): ')
session=requests.Session(); session.headers.update({'Authorization':'Bearer '+secret,'User-Agent':'PieBot performance audit'})
r=session.get('https://lichess.org/api/games/user/PieBot',params=params,headers={'Accept':'application/x-ndjson'},stream=True,timeout=(20,180))
if r.status_code!=200: raise SystemExit('Lichess export HTTP '+str(r.status_code))
games=[]
with (OUT/'games.ndjson').open('w') as f:
 for line in r.iter_lines():
  if line:
   obj=json.loads(line); games.append(obj); f.write(line.decode()+'\n'); f.flush()
   if len(games)%25==0: print('Downloaded',len(games),'games',flush=True)
assert all(params['since']<=g['createdAt']<=params['until'] for g in games)
assert len({g['id'] for g in games})==len(games)
pg='\n\n'.join(g.get('pgn','').strip() for g in games if g.get('pgn'))
(OUT/'games.pgn').write_text(pg+'\n')
r=session.get('https://lichess.org/api/user/PieBot',timeout=(20,40)); r.raise_for_status()
(OUT/'profile.json').write_text(json.dumps(r.json(),indent=2)+'\n')
meta={'account':'PieBot','since_utc':since.isoformat(),'until_utc':until.isoformat(),'filter':'game creation time','endpoint':'https://lichess.org/api/games/user/PieBot','params':params,'downloaded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'games':len(games),'pgn_games':sum(bool(g.get('pgn')) for g in games),'sha256':{n:hashlib.sha256((OUT/n).read_bytes()).hexdigest() for n in ('games.ndjson','games.pgn')}}
(OUT/'window.json').write_text(json.dumps(meta,indent=2)+'\n'); print(json.dumps(meta,indent=2))
session.close(); secret=None
