import json,os,time,hashlib
from pathlib import Path
import chess,chess.engine
BASE=Path('/home/ubuntu/lichess-bot/engines/PieBot');BIN=BASE/'PieBot/target/release/uci';MODEL=BASE/'models/lc0_chunk_00034965.nnue'
CASES_PLACEHOLDER=[{'game': 'sEi3c6E4', 'ply': 43, 'history': ['d2d4', 'g8f6', 'c2c4', 'e7e6', 'g1f3', 'd7d5', 'c4d5', 'e6d5', 'b1c3', 'c8f5', 'd1b3', 'b8c6', 'c1g5', 'c6a5', 'b3a4', 'c7c6', 'g5f6', 'g7f6', 'e2e3', 'b7b5', 'a4d1', 'f5g6', 'h2h4', 'b5b4', 'c3a4', 'f8d6', 'a4c5', 'e8g8', 'h4h5', 'g6e4', 'c5e4', 'd5e4', 'f3h4', 'd8c8', 'd1a4', 'a5b7', 'g2g4', 'c8g4', 'a4c6', 'a8b8', 'c6d5', 'b4b3']}, {'game': 'zQoaxfK6', 'ply': 3, 'history': ['d2d4', 'f7f5']}, {'game': 'aGvveGBK', 'ply': 66, 'history': ['e2e4', 'e7e5', 'g1f3', 'b8c6', 'f1b5', 'a7a6', 'b5a4', 'g8f6', 'd2d3', 'f8c5', 'a4b3', 'd7d6', 'a2a4', 'h7h6', 'c1e3', 'c5e3', 'f2e3', 'c8e6', 'b3e6', 'f7e6', 'b1c3', 'd8e7', 'e1g1', 'e8c8', 'd3d4', 'h8f8', 'd1d3', 'c8b8', 'a4a5', 'g7g5', 'a1a4', 'e5d4', 'e3d4', 'g5g4', 'f3d2', 'f6d7', 'f1f8', 'd8f8', 'd3e3', 'h6h5', 'd4d5', 'e6d5', 'c3d5', 'e7g7', 'c2c3', 'd7e5', 'd2c4', 'h5h4', 'b2b3', 'e5f3', 'g1h1', 'h4h3', 'a4a2', 'f3h4', 'a2f2', 'h3g2', 'h1g1', 'f8f3', 'f2f3', 'g4f3', 'e3f2', 'g7h7', 'f2e1', 'h7h6', 'e1e3']}, {'game': 'U0E0YGi4', 'ply': 61, 'history': ['e2e4', 'c7c5', 'g1f3', 'e7e6', 'd2d4', 'c5d4', 'f3d4', 'a7a6', 'c2c4', 'f8c5', 'd4b3', 'c5a7', 'b1c3', 'd7d6', 'd1e2', 'g8f6', 'c1e3', 'e8g8', 'e3a7', 'a8a7', 'e1c1', 'b7b6', 'g2g4', 'b6b5', 'c4b5', 'a7c7', 'c1b1', 'a6b5', 'g4g5', 'f6e8', 'c3b5', 'c7b7', 'f2f4', 'd8b6', 'e2d2', 'b8c6', 'f1e2', 'e6e5', 'f4f5', 'c6e7', 'f5f6', 'g7f6', 'g5f6', 'e7g6', 'b5d6', 'e8d6', 'd2d6', 'b6e3', 'd6d3', 'e3b6', 'd3d6', 'b6e3', 'd6d3', 'e3b6', 'd1d2', 'c8e6', 'e2d1', 'f8a8', 'd3c3', 'g8h8']}, {'game': 'RbqMJLNn', 'ply': 32, 'history': ['e2e4', 'e7e5', 'g1f3', 'b8c6', 'f1b5', 'g8f6', 'e1g1', 'f6e4', 'd2d4', 'e4d6', 'd4e5', 'd6b5', 'c2c4', 'd7d6', 'c4b5', 'c6e5', 'f1e1', 'f8e7', 'f3e5', 'd6e5', 'd1d8', 'e7d8', 'e1e5', 'c8e6', 'b1c3', 'd8f6', 'e5e1', 'e8c8', 'c1f4', 'd8d7', 'a1c1']}]
rows=[]
for threads in (1,2):
 active=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   if os.path.realpath(str(p/'exe'))==str(BIN):active.append(p.name)
  except (OSError,PermissionError):pass
 if active:
  print(json.dumps({'status':'skipped_active_bot_game','active':active,'rows':rows}));raise SystemExit()
 e=chess.engine.SimpleEngine.popen_uci(str(BIN),cwd=BASE,env=dict(os.environ,RAYON_NUM_THREADS=str(threads)))
 e.configure({'Threads':threads,'Hash':512,'UseNNUE':True,'NNUEQuantFile':str(MODEL),'EvalBlend':100});e.configure({'EvalBlend':75})
 try:
  for case in CASES_PLACEHOLDER:
   b=chess.Board()
   for u in case['history']:b.push_uci(u)
   t=time.monotonic();r=e.play(b,chess.engine.Limit(depth=12),game=object(),info=chess.engine.INFO_ALL)
   rows.append({'game':case['game'],'ply':case['ply'],'threads':threads,'move':r.move.uci(),'san':b.san(r.move),'depth':r.info.get('depth'),'nodes':r.info.get('nodes'),'cp_stm':r.info['score'].pov(b.turn).score(mate_score=100000),'elapsed_s':time.monotonic()-t})
 finally:e.quit()
print(json.dumps({'status':'complete','binary_sha256':hashlib.sha256(BIN.read_bytes()).hexdigest(),'rows':rows}))
