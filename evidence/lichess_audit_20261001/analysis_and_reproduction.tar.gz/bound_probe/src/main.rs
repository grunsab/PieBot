pub use piebot::search;
pub mod eval {pub mod nnue {pub use piebot::eval::nnue::{loader,Nnue}; #[path = "/Users/rishisachdev/Documents/GitHub/chess_engines/piebot/piebot_rust/PieBot/src/eval/nnue/features.rs"] pub mod features; #[path = "/Users/rishisachdev/Documents/GitHub/chess_engines/piebot/piebot_rust/PieBot/src/eval/nnue/network.rs"] pub mod network;}}
mod archived;
use cozy_chess::Board;
use piebot::eval::nnue::loader::QuantNnue;
use serde_json::{Value,json};
use std::{fs,time::Duration};
fn main(){
 let a:Vec<_>=std::env::args().collect();
 let cases:Value=serde_json::from_str(&fs::read_to_string(&a[1]).unwrap()).unwrap();
 let model=QuantNnue::load_quantized(&a[2]).unwrap();
 let mut s=archived::Searcher::default();s.set_nnue_quant_model(model);s.set_use_nnue(true);s.set_eval_blend_percent(75);
 for case in cases.as_array().unwrap(){
  s.set_tt_capacity_mb(512);s.clear_history();
  let history:Vec<Board>=case["history_fens"].as_array().unwrap().iter().map(|f|Board::from_fen(f.as_str().unwrap(),false).unwrap()).collect();
  let b=history.last().unwrap();s.set_position_history(&history);
  eprintln!("CASE {} {}",case["game"],case["ply"]);
  let p=archived::SearchParams{depth:case["live_depth"].as_u64().unwrap() as u32,movetime:Some(Duration::from_secs(30)),threads:2,use_tt:true,order_captures:true,use_history:true,use_killers:true,use_lmr:true,use_nullmove:true,use_aspiration:true,aspiration_window_cp:35,deterministic:false,..Default::default()};
  let r=s.search_with_params(b,p);
  println!("{}",json!({"game":case["game"],"ply":case["ply"],"bestmove":r.bestmove,"score":r.score_cp,"depth":r.depth,"nodes":r.nodes}));
 }
}
