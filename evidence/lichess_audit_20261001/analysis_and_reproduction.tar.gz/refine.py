import concurrent.futures,hashlib,json,time
from pathlib import Path
import chess,chess.engine
P=Path(__file__).resolve().parent;ROOT=P.parents[1];ENGINE=ROOT/'out/thread_anchor_20260929/bin/stockfish-18'
games={g['id']:g for g in map(json.loads,(P/'games.ndjson').read_text().splitlines())}; rows=json.loads((P/'game_summary.json').read_text())['games'];candidates=[]
for g in rows:
 if g['score']!=0:continue
 d=json.loads((P/'sf_screen'/f"{g['id']}.json").read_text()); side=1 if g['color']=='white' else -1
 moves=[]
 for a,b in zip(d['positions'],d['positions'][1:]):
  if (a['ply']%2==0)!=(g['color']=='white'):continue
  before=a['cp_white']*side;after=b['cp_white']*side
  moves.append({'game':g['id'],'ply':a['ply']+1,'before':before,'after':after,'loss':before-after})
 decisive=[x for x in moves if x['before']>=-150 and x['after']<=-200 and x['loss']>=150]
 choice=decisive[0] if decisive else max([x for x in moves if x['before']>=-200] or moves,key=lambda x:x['loss'])
 candidates.append(choice)
for gid,ply in [('sEi3c6E4',43),('zQoaxfK6',3),('aGvveGBK',66),('U0E0YGi4',61),('RbqMJLNn',32)]:
 if not any(x['game']==gid and x['ply']==ply for x in candidates):candidates.append({'game':gid,'ply':ply})
(P/'refine_candidates.json').write_text(json.dumps(candidates,indent=2)+'\n');(P/'sf_refined').mkdir(exist_ok=True)
def run(c):
 gid,ply=c['game'],c['ply'];target=P/'sf_refined'/f'{gid}_{ply}.json'
 if target.exists():return gid,ply,'cached'
 board=chess.Board();g=games[gid]; sans=g['moves'].split()
 for san in sans[:ply-1]:board.push_san(san)
 move=board.parse_san(sans[ply-1]);side=board.turn
 e=chess.engine.SimpleEngine.popen_uci(str(ENGINE));e.configure({'Threads':1,'Hash':128,'UCI_LimitStrength':False,'SyzygyProbeLimit':0})
 def convert(info):
  b=board.copy(); pv=[]
  for m in info.get('pv',[])[:14]:pv.append(b.san(m));b.push(m)
  return {'cp_stm':info['score'].pov(side).score(mate_score=100000),'mate':info['score'].pov(side).mate(),'depth':info.get('depth'),'nodes':info.get('nodes'),'pv':pv,'pv_uci':[m.uci() for m in info.get('pv',[])[:14]]}
 try:
  best=convert(e.analyse(board,chess.engine.Limit(nodes=2000000),game=object()))
  played=convert(e.analyse(board,chess.engine.Limit(nodes=2000000),root_moves=[move],game=object()))
 finally:e.quit()
 out={**c,'fen':board.fen(),'played_move':move.uci(),'played_san':sans[ply-1],'best':best,'played':played,'cp_loss':max(0,best['cp_stm']-played['cp_stm'])}
 target.write_text(json.dumps(out,indent=2)+'\n');return gid,ply,out['cp_loss']
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 for i,f in enumerate(concurrent.futures.as_completed([pool.submit(run,c) for c in candidates]),1):print(i,len(candidates),f.result(),flush=True)
