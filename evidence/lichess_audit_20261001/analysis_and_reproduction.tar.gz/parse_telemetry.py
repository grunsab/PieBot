import collections,datetime,json,re,statistics
from pathlib import Path
import chess
P=Path(__file__).resolve().parent
lines=sorted((P/'server_logs.txt').read_text().splitlines(),key=lambda s:s[:23])
games={g['id']:g for g in map(json.loads,(P/'games.ndjson').read_text().splitlines())}
expected={}
for gid,g in games.items():
 board=chess.Board(); ucis=[]
 for san in g['moves'].split():
  mv=board.parse_san(san); ucis.append(mv.uci()); board.push(mv)
 expected[gid]=ucis
last_game=None; states={}; records=[]; settings=collections.defaultdict(list)
for line in lines:
 m=re.search(r'Searching for .* for game (\w+)',line)
 if m: last_game=m[1]
 m=re.search(r'\(pid=(\d+)\)>: (<<|>>) (.*)',line)
 if not m: continue
 pid,direction,msg=m.groups(); s=states.setdefault(pid,{})
 if msg.startswith('setoption') or msg.startswith('option name UseNNUE'): settings[pid].append(msg)
 if direction=='<<' and msg.startswith('position '): s['position']=msg
 if direction=='<<' and msg.startswith('go '):
  s.update({'game':last_game,'go':msg,'started':line[:23],'info':None})
 if direction=='>>' and msg.startswith('info depth'): s['info']=msg
 if direction=='>>' and msg.startswith('bestmove ') and s.get('go'):
  gid=s.get('game'); history=s.get('position','').split(' moves '); moves=history[1].split() if len(history)>1 else []
  plies=len(moves); best=msg.split()[1]
  elapsed=(datetime.datetime.fromisoformat(line[:23].replace(',','.'))-datetime.datetime.fromisoformat(s['started'].replace(',','.'))).total_seconds()
  record={'game':gid,'pid':int(pid),'ply':plies+1,'history':moves,'bestmove':best,'go':s['go'],'started_at':s['started'],'elapsed_s':elapsed,'info':s['info']}
  if s['info']:
   for k in ('depth','seldepth','nodes'):
    v=re.search(r'\b'+k+r' (\d+)',s['info']); record[k]=int(v[1]) if v else None
   v=re.search(r'score (cp|mate) (-?\d+)',s['info']); record['score_kind'],record['score']=v[1],int(v[2])
   record['nps']=record['nodes']/elapsed if elapsed>0 else None
  if gid in expected:
   assert expected[gid][:plies]==moves,(gid,plies,'history mismatch')
   record['played']=plies<len(expected[gid])
   if record['played']: assert expected[gid][plies]==best,(gid,plies,'move mismatch')
  records.append(record); s['go']=None
matched=[r for r in records if r['game'] in games and r.get('played')]
(P/'telemetry.json').write_text(json.dumps({'records':matched,'engine_settings':settings},indent=2)+'\n')
def metrics(rs):
 rs=[r for r in rs if r.get('nodes') is not None]
 return {'moves':len(rs),'median_depth':statistics.median(r['depth'] for r in rs),'mean_depth':statistics.mean(r['depth'] for r in rs),'median_nps':statistics.median(r['nps'] for r in rs if r.get('nps')),'aggregate_nps':sum(r['nodes'] for r in rs)/sum(r['elapsed_s'] for r in rs),'median_search_s':statistics.median(r['elapsed_s'] for r in rs),'mean_search_s':statistics.mean(r['elapsed_s'] for r in rs),'median_nodes':statistics.median(r['nodes'] for r in rs)}
summary={'logged_moves':len(records),'matched_moves':len(matched),'matched_games':len(set(r['game'] for r in matched)),'all':metrics(matched),'opening_middle_ply_10_to_60':metrics([r for r in matched if 10<=r['ply']<=60]),'by_pool':{pool:metrics([r for r in matched if games[r['game']]['speed']==pool]) for pool in ('bullet','blitz')},'nnue_true_starts':sum('option name UseNNUE type check default true' in s for s in lines),'nnue_false_starts':sum('option name UseNNUE type check default false' in s for s in lines),'ponder_commands':sum('<< go ponder' in s for s in lines)}
(P/'telemetry_summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
