import concurrent.futures,datetime,hashlib,json,time
from pathlib import Path
import chess,chess.engine
OUT=Path(__file__).resolve().parent; ROOT=OUT.parents[1]
ENGINE=ROOT/'out/thread_anchor_20260929/bin/stockfish-18'
GAMES=[json.loads(l) for l in (OUT/'games.ndjson').read_text().splitlines()]
NODES=50000
def analyze(g):
 target=OUT/'sf_screen'/f"{g['id']}.json"
 if target.exists(): return g['id'],'cached'
 e=chess.engine.SimpleEngine.popen_uci(str(ENGINE),timeout=60)
 e.configure({'Threads':1,'Hash':64,'UCI_LimitStrength':False,'SyzygyProbeLimit':0})
 board=chess.Board(g.get('initialFen',chess.STARTING_FEN)); positions=[]; sans=g['moves'].split()
 started=time.monotonic()
 try:
  for ply in range(len(sans)+1):
   if board.is_game_over(claim_draw=True):
    outcome=board.outcome(claim_draw=True); cp=0 if outcome.winner is None else (100000 if outcome.winner else -100000); info={}; pv=[]
   else:
    info=e.analyse(board,chess.engine.Limit(nodes=NODES)); cp=info['score'].white().score(mate_score=100000); pv=[m.uci() for m in info.get('pv',[])[:10]]
   positions.append({'ply':ply,'cp_white':cp,'depth':info.get('depth'),'nodes':info.get('nodes'),'pv':pv})
   if ply<len(sans): board.push_san(sans[ply])
 finally: e.quit()
 record={'id':g['id'],'engine':'Stockfish 18 full strength','nodes_per_position':NODES,'positions':positions,'elapsed_s':time.monotonic()-started}
 target.write_text(json.dumps(record)+'\n'); return g['id'],round(record['elapsed_s'],1)
(OUT/'sf_screen').mkdir(exist_ok=True)
(OUT/'sf_screen_manifest.json').write_text(json.dumps({'engine':str(ENGINE),'sha256':hashlib.sha256(ENGINE.read_bytes()).hexdigest(),'nodes_per_position':NODES,'threads_per_process':1,'concurrent_games':4,'games':len(GAMES),'purpose':'Screen all game positions, then recheck critical mistakes at a larger budget. Evaluations are analysis only, never training labels.'},indent=2)+'\n')
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 for i,f in enumerate(concurrent.futures.as_completed([pool.submit(analyze,g) for g in GAMES]),1):
  print(i,len(GAMES),f.result(),flush=True)
print('Complete',datetime.datetime.now(datetime.timezone.utc).isoformat(),flush=True)
